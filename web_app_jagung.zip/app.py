"""
Web demo: Klasifikasi Penyakit Daun Jagung (fitur GLCM + HSV, K-NN & Random Forest)
Jalankan:  streamlit run app.py
"""
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import streamlit as st
from PIL import Image

from glcm_features import all_feature_names, extract_features, load_rgb

BASE = Path(__file__).parent
MODEL_DIR = BASE / 'models'
NAMA_MODEL = {'knn': 'K-Nearest Neighbor', 'rf': 'Random Forest'}

st.set_page_config(page_title='Penyakit Daun Jagung', page_icon='🌽', layout='wide')


@st.cache_resource
def muat_model():
    cfg = json.loads((MODEL_DIR / 'config.json').read_text(encoding='utf-8'))
    models = {key: joblib.load(MODEL_DIR / f'{key}_model.pkl') for key in NAMA_MODEL}
    return cfg, models


cfg, models = muat_model()
NAMA_KELAS = cfg.get('class_display', {})

st.title('🌽 Klasifikasi Penyakit Daun Jagung')
st.write('Ekstraksi fitur tekstur **GLCM** dan warna **HSV**, lalu klasifikasi dengan '
         '**K-Nearest Neighbor** dan **Random Forest**.')

with st.sidebar:
    st.header('Tentang model')
    st.write('Kelas yang dikenali:')
    for c in cfg['class_names']:
        st.markdown(f'- {NAMA_KELAS.get(c, c)}')
    st.write(f"Fitur: {cfg.get('feature_set', 'GLCM')} ({len(cfg['feature_names'])} fitur)")
    st.subheader('Hasil pada data uji')
    hasil = pd.DataFrame(cfg['test_metrics']).T
    hasil.index = [NAMA_MODEL.get(i, i) for i in hasil.index]
    st.dataframe(hasil.map(lambda v: f'{v:.2%}'))

file = st.file_uploader('Unggah foto satu helai daun jagung (sebaiknya berlatar polos)',
                        type=['jpg', 'jpeg', 'png', 'bmp', 'webp'])
if file is None:
    st.info('Silakan unggah gambar untuk mulai memprediksi.')
    st.stop()

try:
    img = Image.open(file)
    img.load()                                    # paksa membaca seluruh isi file
    fitur, mask, ok = extract_features(img)
    rgb = load_rgb(img)
except Exception:
    st.error('File tidak dapat dibaca sebagai gambar. Unggah file JPG/PNG yang valid.')
    st.stop()
overlay = rgb.copy()
overlay[~mask] = (overlay[~mask] * 0.25).astype(np.uint8)

kiri, kanan = st.columns(2)
kiri.image(rgb, caption='Citra masukan (256 x 256)')
kanan.image(overlay, caption='Area daun hasil segmentasi' if ok
            else 'Segmentasi gagal, seluruh citra dipakai')

X = pd.DataFrame([fitur], columns=all_feature_names())[cfg['feature_names']]
st.subheader('Hasil prediksi')
kolom = st.columns(len(models))
for k, (key, model) in zip(kolom, models.items()):
    proba = model.predict_proba(X)[0]
    kelas = [NAMA_KELAS.get(str(c), str(c)) for c in model.classes_]
    i = int(np.argmax(proba))
    k.markdown(f'#### {NAMA_MODEL[key]}')
    k.metric('Prediksi', kelas[i])
    k.caption(f'Keyakinan: {proba[i]:.1%}')
    k.bar_chart(pd.DataFrame({'Probabilitas': proba}, index=kelas))

with st.expander('Lihat nilai fitur gambar ini'):
    st.dataframe(X.T.rename(columns={0: 'Nilai'}))
