# Web Demo Klasifikasi Penyakit Daun Jagung (GLCM + HSV, K-NN & Random Forest)

## Menjalankan di komputer sendiri (Windows)
1. Pasang **Python 3.13** dari https://www.python.org/downloads/
   (versi ini SAMA dengan Google Colab saat model dilatih; centang "Add python.exe to PATH").
   Versi Python yang lebih baru bisa gagal memasang scikit-learn==1.6.1.
2. Ekstrak zip ini, buka foldernya di File Explorer, klik address bar, ketik cmd, tekan Enter.
3. Jalankan:
       py -3.13 -m pip install -r requirements.txt
       py -3.13 -m streamlit run app.py
4. Browser akan terbuka di http://localhost:8501 (tutup dengan Ctrl + C di terminal).

Mac/Linux: pakai python3.13 -m pip ... dan python3.13 -m streamlit run app.py

## Online gratis (Streamlit Community Cloud)
1. Unggah isi folder ini ke repository GitHub.
2. Buka https://share.streamlit.io, pilih repository, file utama: app.py,
   pada Advanced settings pilih Python 3.13, lalu Deploy.

Isi folder: app.py (tampilan web), glcm_features.py (preprocessing + fitur GLCM & HSV, sama dengan saat melatih),
models/ (knn_model.pkl, rf_model.pkl, config.json), requirements.txt.
