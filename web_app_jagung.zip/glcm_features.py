"""
glcm_features.py
Preprocessing + ekstraksi fitur tekstur GLCM dan warna HSV untuk citra daun jagung.

File ini dipakai di DUA tempat: notebook (saat melatih model) dan web app
(saat memprediksi). Karena kodenya sama persis, gambar yang diunggah ke web
diproses dengan cara yang identik dengan data latih.
"""
import numpy as np
from PIL import Image
from scipy import ndimage as ndi
from skimage.color import rgb2hsv
from skimage.feature import graycomatrix, graycoprops

IMG_SIZE = 256                      # ukuran citra PlantVillage (256 x 256)
LEVELS = 64                         # jumlah tingkat keabuan GLCM (256 -> 64)
DISTANCES = [1, 2, 3]               # jarak piksel bertetangga
ANGLES = [0, np.pi / 4, np.pi / 2, 3 * np.pi / 4]   # 0, 45, 90, 135 derajat
PROPS = ['contrast', 'dissimilarity', 'homogeneity', 'energy', 'ASM', 'correlation']

BATAS_GELAP = 0.12        # V < 0.12 -> latar hitam
BATAS_SATURASI = 0.12     # S < 0.12 -> latar abu-abu/putih (daun jagung S > 0.15)
LUAS_MIN = 0.01           # potongan daun < 1% luas citra dibuang (noise)


WARNA = [f'{k}_{m}' for k in ('H', 'S', 'V') for m in ('mean', 'std', 'skew')]


def feature_names(distances=DISTANCES):
    """Nama kolom fitur GLCM, contoh: contrast_d1, entropy_d3."""
    return [f'{p}_d{d}' for d in distances for p in PROPS + ['entropy']]


def all_feature_names():
    """21 fitur GLCM + 9 fitur warna HSV (urutan sama dengan extract_features)."""
    return feature_names() + WARNA


def load_rgb(source, size=IMG_SIZE):
    """Buka gambar (path / file upload / PIL.Image) -> array RGB uint8 size x size."""
    img = source if isinstance(source, Image.Image) else Image.open(source)
    img = img.convert('RGB')                      # buang kanal alpha / grayscale -> 3 kanal
    if img.size != (size, size):
        img = img.resize((size, size), Image.BILINEAR)
    return np.asarray(img, dtype=np.uint8)


def to_gray(rgb):
    """RGB -> grayscale (luminance ITU-R BT.601)."""
    rgb = rgb.astype(np.float64)
    return 0.299 * rgb[..., 0] + 0.587 * rgb[..., 1] + 0.114 * rgb[..., 2]


def _disk(r):
    y, x = np.ogrid[-r:r + 1, -r:r + 1]
    return x * x + y * y <= r * r


def segment_leaf(rgb):
    """
    Segmentasi daun berbasis warna (HSV).
    Latar = piksel hitam (V kecil) atau abu-abu (saturasi S kecil) YANG TERSAMBUNG
    ke tepi gambar. Bagian pucat di tengah daun (bercak, pantulan cahaya) tetap
    dihitung sebagai daun. Mengembalikan (mask_daun, berhasil). Jika tidak ada
    latar (daun memenuhi bingkai), seluruh citra dianggap daun.
    """
    hsv = rgb2hsv(rgb)
    S, V = hsv[..., 1], hsv[..., 2]
    kandidat = (V < BATAS_GELAP) | (S < BATAS_SATURASI)
    lab, _ = ndi.label(kandidat)
    tepi = np.unique(np.concatenate([lab[0, :], lab[-1, :], lab[:, 0], lab[:, -1]]))
    latar = np.isin(lab, tepi[tepi > 0])
    daun = ndi.binary_opening(~latar, structure=_disk(2))
    daun = ndi.binary_fill_holes(daun)
    lab, n = ndi.label(daun)
    if n > 0:
        luas = np.bincount(lab.ravel())
        luas[0] = 0
        daun = np.isin(lab, np.where(luas >= LUAS_MIN * daun.size)[0])
    frac = daun.mean()
    if frac < 0.05:                               # segmentasi gagal
        return np.ones(S.shape, bool), False
    if frac > 0.97:                               # daun memenuhi bingkai
        return np.ones(S.shape, bool), True
    return daun, True


def glcm_features(gray, mask, distances=DISTANCES, levels=LEVELS):
    """
    Hitung fitur GLCM HANYA pada area daun (latar diabaikan).
    Untuk tiap jarak: 7 fitur dirata-rata dari 4 sudut.
    """
    # Kuantisasi 0..255 -> 1..levels-1; nilai 0 dicadangkan untuk latar
    q = np.floor(np.clip(gray, 0, 255) / 256.0 * (levels - 1)).astype(np.uint8) + 1
    q[~mask] = 0
    P = graycomatrix(q, distances=distances, angles=ANGLES, levels=levels,
                     symmetric=True, normed=False)
    P = P[1:, 1:, :, :].astype(np.float64)        # buang pasangan yang melibatkan latar

    fitur = []
    for i in range(len(distances)):
        Pd = P[:, :, i:i + 1, :]
        total = Pd.sum(axis=(0, 1), keepdims=True)
        total[total == 0] = 1.0
        Pn = Pd / total
        nilai = {p: float(graycoprops(Pn, p)[0].mean()) for p in PROPS}
        ent = []
        for a in range(Pn.shape[3]):
            p = Pn[:, :, 0, a]
            p = p[p > 0]
            ent.append(float(-(p * np.log2(p)).sum()))
        nilai['entropy'] = float(np.mean(ent))
        fitur.extend(nilai[k] for k in PROPS + ['entropy'])
    return np.asarray(fitur, dtype=np.float64)


def color_features(rgb, mask):
    """Momen warna HSV pada area daun: mean, standar deviasi, skewness tiap kanal."""
    hsv = rgb2hsv(rgb)
    fitur = []
    for c in range(3):
        v = hsv[..., c][mask].astype(np.float64)
        mu, sd = v.mean(), v.std()
        sk = float(np.mean((v - mu) ** 3) / sd ** 3) if sd > 1e-12 else 0.0
        fitur += [float(mu), float(sd), sk]
    return np.asarray(fitur, dtype=np.float64)


def extract_features(source):
    """Pipeline lengkap: buka -> RGB 256x256 -> segmentasi daun -> GLCM (grayscale) + warna HSV.
    Mengembalikan (vektor 30 fitur sesuai all_feature_names(), mask, segmentasi_berhasil)."""
    rgb = load_rgb(source)
    mask, ok = segment_leaf(rgb)
    f = np.concatenate([glcm_features(to_gray(rgb), mask), color_features(rgb, mask)])
    return f, mask, ok
